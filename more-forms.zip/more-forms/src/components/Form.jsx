import React, { useState } from 'react';

const Form = (props) => {
    const [firstname, setFirstname] = useState("");
    const [firstnameError, setFirstnameError] = useState("");
    const [lastname, setLastname] = useState("");
    const [lastnameError, setLastnameError] = useState("");
    const [email, setEmail] = useState("");
    const [emailError, setEmailError] = useState("");
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmpassword, setConfirmpassword] = useState("");
    const [confirmpasswordError, setConfirmpasswordError] = useState("");

    const handleFirstName = (e) => {
        setFirstname(e.target.value);
        if(e.target.value.length < 2){
            setFirstnameError("First name must be more than 2 characters.");
        } else {
            setFirstnameError("");
        }
    }
    const handleLastName = (e) => {
        setLastname(e.target.value);
        if(e.target.value.length < 2){
            setLastnameError("Last name must be more than 2 characters.");
        } else {
            setLastnameError("");
        }
    }
    const handleEmail = (e) => {
        setEmail(e.target.value);
        if(e.target.value.length < 5){
            setEmailError("Email must be more than 5 characters.");
        } else {
            setEmailError("");
        }
    }
    const handlePassword = (e) => {
        setPassword(e.target.value);
        if(e.target.value.length < 8){
            setPasswordError("Password must be more than 8 characters.");
        } else {
            setPasswordError("");
        }
    }
    const handleConfirmPassword = (e) => {
        setConfirmpassword(e.target.value);
        if(e.target.value != password){
            setConfirmpasswordError("Passwords must match!");
        } else if (e.target.value == password) {
            setConfirmpasswordError("");
        }
    }
    const createUser = (e) => {

        e.preventDefault();

        const newUser = { firstname, lastname, email, password, confirmpassword};
        setFirstname("");
        setLastname("");
        setEmail("");
        setPassword("");
        setConfirmpassword("");
    }

    return(
    <div>
        <form onSubmit = { createUser }>
            <div>
                <label>First Name: </label>
                <input type="text" value = {firstname} onChange = { handleFirstName } />
                {
                    firstnameError ? 
                    <p>{firstnameError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Last Name: </label>
                <input type="text" value = {lastname} onChange = { handleLastName } />
                {
                    lastnameError ? 
                    <p>{lastnameError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Email: </label>
                <input type="email" value = {email} onChange = { handleEmail } />
                {
                    emailError ? 
                    <p>{emailError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Password: </label>
                <input type="password" value = {password} onChange = { handlePassword } />
                {
                    passwordError ? 
                    <p>{passwordError}</p>:
                    ''
                }
            </div>
            <div>
                <label>Confirm Password: </label>
                <input type="password" value = {confirmpassword} onChange = { handleConfirmPassword } />
                {
                    confirmpasswordError ? 
                    <p>{confirmpasswordError}</p>:
                    ''
                }
            </div>
                
        </form>
    </div>
        
    )
}

export default Form;